package com.softwarehouse.salescontrol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesControlApplicationTests {

	@Test
	void contextLoads() {
	}

}
